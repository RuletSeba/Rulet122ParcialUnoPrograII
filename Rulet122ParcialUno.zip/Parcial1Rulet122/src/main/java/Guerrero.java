/**
 * Aventurero que pelea cuerpo a cuerpo
 * Poder = fuerza * 2
 */
public class Guerrero extends Aventurero implements Entrenable{
    private final int fuerza;

    /**
     * @param fuerza valor de la fuerza, mayor que 0
     * @throws IllegalArgumentException si la fuerza no es mayor que cero
     */
    public Guerrero(String codigo, String nombre, Rango rango, int fuerza) {
        super(codigo, nombre, rango);
        if (fuerza <= 0){
        throw new IllegalArgumentException("La fuerza debe de ser mayor a cero.");
        }
        this.fuerza = fuerza;
    }

    public int getFuerza() {
        return fuerza;
    }
    

    @Override
    public String atacar() {
        return getNombre() + " golpea cuerpo a cuerpo";
    }

    @Override
    public int calcularPoder() {
        return fuerza * 2;
    }

    @Override
    public String entrenar() {
        return getNombre() + " practica su combate";
    }
    
    
}
