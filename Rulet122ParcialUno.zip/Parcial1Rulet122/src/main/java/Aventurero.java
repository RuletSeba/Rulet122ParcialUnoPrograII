
import java.util.Objects;

/**
 * Aventurero del gremioAventureros. 
 * Clase abstracta de Guerrero, Arquero y Mago.
 */
public abstract class Aventurero implements Combatiente{
    
    private final String codigo;
    private final String nombre;
    private final Rango rango;
/**
 * 
 * @param codigo codigo de identificacion
 * @param nombre nombre
 * @param rango rango (obligatorio)
 */
    public Aventurero(String codigo, String nombre, Rango rango) {        
        this.codigo = Objects.requireNonNull(codigo, "El codigo es obligatorio");
        this.nombre = Objects.requireNonNull(nombre, "El codigo es obligatorio");
        this.rango = Objects.requireNonNull(rango, "El codigo es obligatorio");
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Rango getRango() {
        return rango;
    }
    

    /**
     * Compara por el codigo y nombre
     */
    @Override
    public boolean equals(Object o){
        if(!(o instanceof Aventurero)){
            return false;
        }
        Aventurero otro = (Aventurero) o;
        return codigo.equals(otro.getCodigo()) && nombre.equals(otro.getNombre());
    }

    @Override
    public int hashCode() {
        return codigo.hashCode();
    }
    
    @Override
    public String toString() {
        return codigo + " " + nombre + " " + rango;
    }
    
    
}
