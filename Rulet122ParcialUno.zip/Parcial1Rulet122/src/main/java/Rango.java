/**
 * Rango de un aventurero del gremio
 */
public enum Rango {
    BRONCE,
    PLATA,
    ORO
}
