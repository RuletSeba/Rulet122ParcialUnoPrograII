/**
 * Para aquellos aventureros que tengan entrenamientos especiales
 */
public interface Entrenable {
    /**
     * Describe el entrenamiento del aventurero que lo pueda realizar.
     * @return texto descriptivo del entrenamiento
     */
    String entrenar();
}
