
import java.util.ArrayList;
import java.util.List;

/**
 * El gremio registra y administra a los aventureros.
 */
public class GremioAventureros {

    private final String nombre;
    private final List<Aventurero> aventureros = new ArrayList<>();

    /**
     * @param nombre
 */
    public GremioAventureros(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    /**
     * Agrega a un aventurero de cualquier tipo
     * @param a aventurero a registrar
     * @throws AventureroDuplicadoException si ya existe el aventurero con el mismo codigo y nombre
     */
    public void agregarAventurero(Aventurero a) {
        if (aventureros.contains(a)) {
            throw new AventureroDuplicadoException("Ya existe un aventurero con esas caracteristicas");
        }
        aventureros.add(a);
    }
/**
 * @return copia la lista con todos los aventureros que estan registrados previamente
 */
    public List<Aventurero> obtenerAventureros() {
        return new ArrayList<>(aventureros);
    }

    /**
     * 
     * @param rango rango que se busca
     * @return aventureros que tienen ese rango
     */
    public List<Aventurero> filtrarPorRango(Rango rango) {
        List<Aventurero> r = new ArrayList<>();
        for (Aventurero a : aventureros) {
            if (a.getRango() == rango) {
                r.add(a);
            }
        }
        return r;
    }

    /**
     * 
     * @param poderMinimo poder de combate minimo
     * @return devolver los aventureros cuyo poder de combate sea mayor o igual
al valor recibido
     */
    public List<Aventurero> obtenerAventurerosPoderosos(int poderMinimo) {
        List<Aventurero> r = new ArrayList<>();
        for (Aventurero a : aventureros) {
            if (a.calcularPoder() >= poderMinimo) {
                r.add(a);
            }
        }
        return r;
    }
}
