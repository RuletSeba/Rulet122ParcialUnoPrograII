/**
 * Aventurero que ataca con su arco
 * poder = precision * 3
 */
public class Arquero extends Aventurero implements Entrenable{
    private final int precision;

    /**
     * @param precision valor de precision, mayor que cero
     * @throws IllegalArgumentException si la precision no es mayor que cero
     */
    public Arquero(String codigo, String nombre, Rango rango, int precision) {
        super(codigo, nombre, rango);
        if (precision <= 0){
            throw new IllegalArgumentException("La precision debe de ser mayor a cero.");
        }
        this.precision = precision;
    }

    public int getPrecision() {
        return precision;
    }

    @Override
    public String atacar() {
        return getNombre() + " dispara con su flecha";
    }

    @Override
    public int calcularPoder() {
        return precision * 3;
    }

    @Override
    public String entrenar() {
        return getNombre() + " practica su punteria disparando al blanco con su arco";
    }
    
    

    
    
}
