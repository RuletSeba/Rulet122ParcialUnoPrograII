/**
 * Aventurero que usa su magia
 * poder = mana + 10
 * No tiene entrenamientos especiales
 */
public class Mago extends Aventurero{

    private final int mana;

    /**
     * @param mana puntos de su poder, mayor que cero
     * @throws IllegalArgumentException si el mana no es mayor que cero
     */
    public Mago(String codigo, String nombre, Rango rango, int mana) {
        super(codigo, nombre, rango);
        if (mana <= 0){
            throw new IllegalArgumentException("El mana debe de ser mayor a 0");
        }
        this.mana = mana;
    }

    public int getMana() {
        return mana;
    }
    
    
    
    @Override
    public String atacar() {
        return getNombre() + " lanza un hechizo";
    }

    @Override
    public int calcularPoder() {
        return mana + 10;
    }
    
}
