/**
 * La excepcion se lanza cuando se intenta agregar un aventurero que ya existe dentro del GremioAventureros
 */
public class AventureroDuplicadoException extends RuntimeException {
    
    /**
     * @param msg Mensaje para la excepcion
     */
    public AventureroDuplicadoException(String msg) {
        super("Ya existe un aventurero con esas caracteristicas");
    }
}
