/**
 * Para los aventureros que pueden combatir
 */
public interface Combatiente {
    /**
     * Describe el ataque del aventurero combatiente
     * @return texto del ataque
     */
    String atacar();
    
    /**
     * Calcula el poder de combate segun el aventuero
     * @return poder de combate
     */
    int calcularPoder();
            
}
